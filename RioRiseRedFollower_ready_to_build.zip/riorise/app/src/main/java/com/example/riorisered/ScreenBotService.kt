package com.example.riorisered

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import androidx.core.app.NotificationCompat
import kotlin.math.*
import java.util.concurrent.Executors

class ScreenBotService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var running = true
    private val exec = Executors.newSingleThreadExecutor()

    // OPPO Reno14 5G (CPH2737) landscape reference: 2760 x 1256.
    // Values come from the supplied 1582 x 720 game recording and are scaled.
    private val REF_W = 1582f
    private val REF_H = 720f
    private val joyX = 267f
    private val joyY = 507f
    private val joyRadius = 105f

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, NotificationCompat.Builder(this, "bot")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Rio Rise bot aktif")
            .setContentText("Tekan HENTIKAN untuk berhenti.")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "HENTIKAN",
                PendingIntent.getService(this, 8,
                    Intent(this, ScreenBotService::class.java).setAction("STOP"),
                    PendingIntent.FLAG_IMMUTABLE))
            .build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            running = false
            stopSelf()
            return START_NOT_STICKY
        }
        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        } ?: return START_NOT_STICKY
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        startCapture()
        return START_STICKY
    }

    private fun startCapture() {
        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels,
            PixelFormat.RGBA_8888, 2)

        projection?.createVirtualDisplay(
            "RioRiseBot", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            0, reader!!.surface, null, null
        )

        reader!!.setOnImageAvailableListener({ r ->
            if (!running) return@setOnImageAvailableListener
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * image.width
                val bmp = Bitmap.createBitmap(
                    image.width + rowPadding / pixelStride,
                    image.height, Bitmap.Config.ARGB_8888
                )
                buffer.rewind()
                bmp.copyPixelsFromBuffer(buffer)
                process(bmp)
                bmp.recycle()
            } finally { image.close() }
        }, Handler(Looper.getMainLooper()))
    }

    private var lastCommand = 0L
    private var stableX = 0f
    private var stableY = 0f
    private var stableFrames = 0
    private var lastSeen = 0L

    private fun process(bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height

        // The game is landscape. The supplied recording has the same aspect ratio
        // as Reno14 5G in landscape (2760 x 1256).
        val sx = w / REF_W
        val sy = h / REF_H

        // Gameplay only: exclude top HUD/minimap, bottom status area and
        // the left joystick area. This dramatically reduces UI false positives.
        val x1 = (300f * sx).toInt().coerceAtLeast(0)
        val x2 = (1510f * sx).toInt().coerceAtMost(w)
        val y1 = (85f * sy).toInt().coerceAtLeast(0)
        val y2 = (685f * sy).toInt().coerceAtMost(h)

        // Red-zone candidate must be reasonably compact and persistent.
        var minX = w; var minY = h; var maxX = 0; var maxY = 0
        var count = 0
        var sumX = 0.0
        var sumY = 0.0

        for (y in y1 until y2 step 4) {
            for (x in x1 until x2 step 4) {
                val c = bmp.getPixel(x, y)
                val r = android.graphics.Color.red(c)
                val g = android.graphics.Color.green(c)
                val b = android.graphics.Color.blue(c)

                // Tuned for a translucent red zone over brown soil.
                // Red must dominate green/blue without requiring pure red.
                val redDominant = r > 105 && r > g * 1.18 && r > b * 1.12
                if (redDominant) {
                    count++
                    sumX += x
                    sumY += y
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        if (count < 55) {
            if (System.currentTimeMillis() - lastSeen > 700) {
                stableFrames = 0
            }
            return
        }

        val bw = maxX - minX
        val bh = maxY - minY

        // Reject text/icon-like shapes and huge red UI panels.
        if (bw < 20*sx || bh < 20*sy ||
            bw > 700*sx || bh > 420*sy) return

        val txRaw = (sumX / count).toFloat()
        val tyRaw = (sumY / count).toFloat()

        // Require the same target to remain approximately in place for 3 frames.
        if (stableFrames == 0) {
            stableX = txRaw
            stableY = tyRaw
            stableFrames = 1
        } else {
            val jump = hypot((txRaw-stableX).toDouble(), (tyRaw-stableY).toDouble())
            if (jump < 180*sx) {
                stableX = stableX * 0.65f + txRaw * 0.35f
                stableY = stableY * 0.65f + tyRaw * 0.35f
                stableFrames++
            } else {
                stableFrames = 1
                stableX = txRaw
                stableY = tyRaw
            }
        }

        lastSeen = System.currentTimeMillis()
        if (stableFrames < 3) return

        // Player position from the recording, scaled to the actual screen.
        val px = 690f * sx
        val py = 500f * sy

        val dx = stableX - px
        val dy = stableY - py
        val dist = hypot(dx.toDouble(), dy.toDouble()).toFloat()

        // Close enough: release by a short center-to-center gesture.
        if (dist < 55*sx) {
            releaseJoystick(w, h)
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastCommand < 190) return
        lastCommand = now

        val len = max(1f, dist)
        val nx = dx / len
        val ny = dy / len

        val jx = joyX * sx
        val jy = joyY * sy
        val jr = joyRadius * min(sx, sy)

        val ex = jx + nx * jr
        val ey = jy + ny * jr

        BotAccessibilityService.instance?.joystickDrag(
            jx, jy, ex, ey, 190
        )
    }

    private fun releaseJoystick(w: Int, h: Int) {
        val sx = w / REF_W
        val sy = h / REF_H
        val jx = joyX * sx
        val jy = joyY * sy
        BotAccessibilityService.instance?.joystickDrag(jx, jy, jx, jy, 80)
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(
            "bot", "Rio Rise Bot", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        running = false
        reader?.close()
        projection?.stop()
        exec.shutdownNow()
        super.onDestroy()
    }
}
