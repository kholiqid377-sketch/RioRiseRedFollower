package com.example.riorisered

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class BotAccessibilityService : AccessibilityService() {
    companion object { var instance: BotAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun joystickDrag(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long = 180L) {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        val stroke = GestureDescription.StrokeDescription(p, 0, duration)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    fun tap(x: Float, y: Float) {
        val p = Path()
        p.moveTo(x, y)
        val stroke = GestureDescription.StrokeDescription(p, 0, 80)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
