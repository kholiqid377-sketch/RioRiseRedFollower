# RioRiseRedFollower - build

Project Android siap dibuild dengan Android Gradle Plugin 8.5.2, Kotlin 1.9.24, compileSdk/targetSdk 35.

## Cara paling mudah dari HP
1. Buat repository GitHub baru (private juga boleh).
2. Upload semua isi folder project ini, termasuk `.github/workflows/build-apk.yml`.
3. Buka tab **Actions** di repository.
4. Pilih **Build APK** lalu tekan **Run workflow**.
5. Setelah selesai, buka hasil run dan download artifact **RioRiseRedFollower-debug**.
6. Ekstrak artifact dan install `app-debug.apk` di OPPO Reno14 5G.

## Izin yang dibutuhkan aplikasi
- Accessibility Service untuk gesture joystick.
- Media Projection untuk membaca layar.
- Foreground service untuk menjalankan bot saat aktif.
