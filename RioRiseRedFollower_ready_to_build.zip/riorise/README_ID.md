# Rio Rise Red Follower — Android

Aplikasi Android prototype yang:
- membaca layar memakai MediaProjection;
- mengabaikan area UI atas/bawah;
- mencari area merah yang cukup besar di area gameplay;
- memakai AccessibilityService untuk menggeser joystick;
- berjalan berulang selama bot aktif.

## Dipakai langsung di HP
Project ini ditujukan untuk dibuka/dibangun memakai IDE Android di HP (misalnya AndroidIDE). Tidak perlu PC untuk proses build jika IDE Android di HP dapat memasang SDK/Gradle yang dibutuhkan.

## Izin
1. Aktifkan Accessibility untuk aplikasi.
2. Tekan Mulai Bot.
3. Izinkan rekam layar.
4. Buka Rio Rise.
5. Hentikan melalui notifikasi.

## Kalibrasi
Kode memakai ukuran video pengguna 1582x720. Jika resolusi HP berbeda, posisi joystick diskalakan otomatis. Posisi pemain dan filter merah masih berupa perkiraan sehingga wajib dites perlahan.

## Catatan
Bot hanya mendeteksi warna merah, bukan memahami objek/game secara semantik. Jika zona pertanian berubah warna/efek, filter perlu disesuaikan.


## Profil HP pengguna: OPPO Reno14 5G
Model CPH2737 menggunakan layar 1256 x 2760 piksel dan 120 Hz. Untuk Rio Rise, layar dipakai landscape sehingga referensinya 2760 x 1256. Posisi joystick dan area deteksi diskalakan dari video 1582 x 720 yang dikirim pengguna.

Jika game tidak memakai full-screen landscape atau ada perubahan layout, koordinat bisa bergeser. Tes dulu beberapa detik.
